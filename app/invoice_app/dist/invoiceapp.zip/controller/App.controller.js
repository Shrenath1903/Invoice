sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("invoiceapp.controller.main",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map